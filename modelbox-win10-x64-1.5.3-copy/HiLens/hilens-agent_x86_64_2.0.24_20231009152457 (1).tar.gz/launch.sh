#!/usr/bin/env sh

{
   WORKING_DIR=$(cd $(dirname $0); pwd;)
   HDAD_FILE=${WORKING_DIR}/hdad
   while true
   do
     HILENS_CHECK_UPGRADE=1 ${HDAD_FILE}
     if [ $? -eq 11 ]; then
       mv /tmp/hilens/hdad ${HDAD_FILE}
     fi
     sleep 3
   done
}
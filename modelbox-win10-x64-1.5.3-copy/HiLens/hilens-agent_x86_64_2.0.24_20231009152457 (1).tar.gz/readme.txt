安装agent
bash install_manual.sh
设备注册绑定
hdactl register_bind -p ./[证书名称].tar.gz
   
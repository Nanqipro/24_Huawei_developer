chmod +x ./hdad && ./hdad install
